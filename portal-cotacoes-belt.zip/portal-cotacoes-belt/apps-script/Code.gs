/*───────────────────────────────────────────────────────────────────────────
  PORTAL DE COTAÇÕES · BELT CORREIAS
  Backend em Google Apps Script — recebe os formulários do index.html
  e grava na planilha "base_cotacao".

  ┌── COMO INSTALAR (uma vez) ─────────────────────────────────────────────┐
  │ 1) Abra a planilha base_cotacao no Google Sheets.                       │
  │ 2) Menu  Extensões ▸ Apps Script.                                       │
  │ 3) Apague o que estiver lá e COLE todo este arquivo. Salve (disquete).  │
  │ 4) (Opcional, planilha nova) Rode a função  criarCabecalho  uma vez.    │
  │ 5) Implantar ▸ Nova implantação ▸ engrenagem ▸ "App da Web":            │
  │       • Descrição:            Portal de Cotações                        │
  │       • Executar como:        Eu (seu e-mail)                           │
  │       • Quem pode acessar:    Qualquer pessoa                           │
  │    Clique Implantar e AUTORIZE quando o Google pedir.                   │
  │ 6) Copie a "URL do app da Web" (termina em /exec).                      │
  │ 7) Cole essa URL no index.html, na constante  CONFIG.WEB_APP_URL.       │
  └────────────────────────────────────────────────────────────────────────┘

  ATUALIZOU O CÓDIGO?  Implantar ▸ Gerenciar implantações ▸ (lápis) ▸
  Versão: Nova versão ▸ Implantar.  (A URL /exec continua a mesma.)
───────────────────────────────────────────────────────────────────────────*/

const SHEET_ID = '11c8K9OJlocuYcnWHreG04NXrPWXQrgG2QgoPKzBzOmQ';
const ABA      = 'Página1';   // nome da guia (aba). Se não existir, usa a 1ª guia.

// Índice das colunas (1 = A, 2 = B, ... 25 = Y)
const C_ID=1, C_DTINC=2, C_REP=3, C_CLI=4, C_QTD=5, C_UM=6, C_PROD=7, C_OBSCOM=8,
      C_DTCOT=9, C_FORN=10, C_PRAZO=11, C_OBSCMP=12, C_M=13, C_N=14, C_O=15, C_P=16,
      C_Q=17, C_R=18, C_S=19, C_T=20, C_U=21, C_V=22, C_W=23, C_URG=24, C_CANC=25;
const TOTAL_COLS = 25;

const FMT_DATA  = 'dd/MM/yyyy HH:mm';
const FMT_MOEDA = '#,##0.00';
const FMT_PCT   = '0.00"%"';

/*──────────────────── ROTEADOR (não mexer) ────────────────────*/

function doGet(e){
  return resposta({ ok:true, msg:'Portal de Cotações · API online', hora:new Date() });
}

function doPost(e){
  const lock = LockService.getScriptLock();
  try { lock.waitLock(30000); }
  catch(err){ return resposta({ ok:false, erro:'Servidor ocupado, tente novamente.' }); }
  try {
    if(!e || !e.postData || !e.postData.contents) throw new Error('Requisição vazia.');
    const dados = JSON.parse(e.postData.contents);
    const acao  = dados.acao;
    const p     = dados.payload || {};
    let res;
    switch(acao){
      case 'criarCotacao':             res = criarCotacao(p);             break;
      case 'editarSolicitacao':        res = editarSolicitacao(p);        break;
      case 'incluirCotacaoFornecedor': res = incluirCotacaoFornecedor(p); break;
      case 'editarCotacaoFornecedor':  res = editarCotacaoFornecedor(p);  break;
      case 'cancelarCotacao':          res = cancelarCotacao(p);          break;
      default: res = { ok:false, erro:'Ação desconhecida: ' + acao };
    }
    return resposta(res);
  } catch(err){
    return resposta({ ok:false, erro:String((err && err.message) || err) });
  } finally {
    lock.releaseLock();
  }
}

/*──────────────────── AÇÕES ────────────────────*/

// COMERCIAL: cria uma nova solicitação (preenche colunas A–H e X)
function criarCotacao(p){
  const sh = getAba();
  const id = proximoId(sh);
  const linha = sh.getLastRow() + 1;
  const v = new Array(TOTAL_COLS).fill('');
  v[C_ID-1]     = id;
  v[C_DTINC-1]  = new Date();
  v[C_REP-1]    = up(p.representante);
  v[C_CLI-1]    = up(p.cliente);
  v[C_QTD-1]    = vazio(p.quantidade) ? '' : num(p.quantidade);
  v[C_UM-1]     = p.unidadeMedida || '';
  v[C_PROD-1]   = up(p.produto);
  v[C_OBSCOM-1] = p.obsComercial || '';
  v[C_URG-1]    = String(p.urgente) === '1' ? '1' : '';
  sh.getRange(linha, 1, 1, TOTAL_COLS).setValues([v]);
  formatarLinha(sh, linha);
  return { ok:true, id:id, linha:linha };
}

// COMERCIAL: edita a solicitação (colunas D–H e X) em TODAS as linhas do ID
function editarSolicitacao(p){
  const sh = getAba();
  const linhas = linhasDoId(sh, p.idCotacao);
  if(!linhas.length) return { ok:false, erro:'Cotação não encontrada: ' + p.idCotacao };
  linhas.forEach(l => {
    sh.getRange(l, C_CLI).setValue(up(p.cliente));
    sh.getRange(l, C_QTD).setValue(vazio(p.quantidade) ? '' : num(p.quantidade));
    sh.getRange(l, C_UM).setValue(p.unidadeMedida || '');
    sh.getRange(l, C_PROD).setValue(up(p.produto));
    sh.getRange(l, C_OBSCOM).setValue(p.obsComercial || '');
    sh.getRange(l, C_URG).setValue(String(p.urgente) === '1' ? '1' : '');
  });
  return { ok:true, linhasAtualizadas:linhas.length };
}

// COMPRAS: inclui uma cotação de fornecedor (preenche colunas I–W)
function incluirCotacaoFornecedor(p){
  const sh = getAba();
  const linhas = linhasDoId(sh, p.idCotacao);
  if(!linhas.length) return { ok:false, erro:'Cotação não encontrada: ' + p.idCotacao };

  // procura uma linha do ID que ainda esteja SEM cotação (coluna I vazia)
  let alvo = -1;
  for(const l of linhas){
    const I = sh.getRange(l, C_DTCOT).getValue();
    if(I === '' || I === null){ alvo = l; break; }
  }

  const c = calcularCustos(p);

  if(alvo === -1){
    // já existe cotação -> NOVA linha duplicando A–H e X, e gravando I–W
    const base = sh.getRange(linhas[0], 1, 1, TOTAL_COLS).getValues()[0];
    alvo = sh.getLastRow() + 1;
    const nova = base.slice();                       // copia A–Y da 1ª linha do ID
    for(let i=C_DTCOT-1; i<=C_W-1; i++) nova[i] = ''; // limpa o bloco I–W
    nova[C_CANC-1] = '';                              // a nova linha não nasce cancelada
    preencherFornecedor(nova, p, c, new Date());
    sh.getRange(alvo, 1, 1, TOTAL_COLS).setValues([nova]);
  } else {
    // preenche I–W na própria linha existente
    const tmp = new Array(TOTAL_COLS).fill('');
    preencherFornecedor(tmp, p, c, new Date());
    const iw = tmp.slice(C_DTCOT-1, C_W);            // fatia I..W (15 células)
    sh.getRange(alvo, C_DTCOT, 1, iw.length).setValues([iw]);
  }
  formatarLinha(sh, alvo);
  return { ok:true, linha:alvo };
}

// COMPRAS: edita a N-ésima cotação de fornecedor do ID (ocorrencia, começa em 0)
function editarCotacaoFornecedor(p){
  const sh = getAba();
  const linhas = linhasDoId(sh, p.idCotacao);
  const oc = parseInt(p.ocorrencia, 10);
  if(!linhas.length || isNaN(oc) || oc < 0 || oc >= linhas.length)
    return { ok:false, erro:'Linha da cotação não encontrada.' };
  const l = linhas[oc];
  const c = calcularCustos(p);
  // NÃO altera a coluna I (mantém a data original da cotação). Grava J, K, L e M–W.
  sh.getRange(l, C_FORN).setValue(up(p.fornecedor));
  sh.getRange(l, C_PRAZO).setValue(p.prazoEntrega || '');
  sh.getRange(l, C_OBSCMP).setValue(p.obsCompras || '');
  const mw = [c.M, c.N, c.O, c.P, c.Q, c.R, c.S, c.T, c.U, c.V, c.W]; // M..W
  sh.getRange(l, C_M, 1, mw.length).setValues([mw]);
  formatarLinha(sh, l);
  return { ok:true, linha:l };
}

// QUALQUER SETOR: cancela (coluna Y) em todas as linhas do ID
// valor: "1" comercial, "2" compras, "3" mestre
function cancelarCotacao(p){
  const sh = getAba();
  const linhas = linhasDoId(sh, p.idCotacao);
  if(!linhas.length) return { ok:false, erro:'Cotação não encontrada: ' + p.idCotacao };
  const valor = String(p.valor);
  linhas.forEach(l => sh.getRange(l, C_CANC).setValue(valor));
  return { ok:true, linhasAtualizadas:linhas.length };
}

/*──────────────────── AUXILIARES ────────────────────*/

function preencherFornecedor(arr, p, c, dataCot){
  arr[C_DTCOT-1]  = dataCot;
  arr[C_FORN-1]   = up(p.fornecedor);
  arr[C_PRAZO-1]  = p.prazoEntrega || '';
  arr[C_OBSCMP-1] = p.obsCompras || '';
  arr[C_M-1]=c.M; arr[C_N-1]=c.N; arr[C_O-1]=c.O; arr[C_P-1]=c.P; arr[C_Q-1]=c.Q;
  arr[C_R-1]=c.R; arr[C_S-1]=c.S; arr[C_T-1]=c.T; arr[C_U-1]=c.U; arr[C_V-1]=c.V; arr[C_W-1]=c.W;
}

// Fórmulas idênticas às do portal (M,N,P,Q,T,V são os campos editáveis)
function calcularCustos(p){
  const M=num(p.custoProduto), N=num(p.ipiPct), P=num(p.fretePct),
        Q=num(p.icmsPct), T=num(p.markupPct), V=num(p.valorAjuste);
  const O = M * (N/100);              // IPI em R$
  const R = M * (Q/100);              // Diferencial de ICMS em R$
  const S = (M + O + R) * (1 + P/100); // Custo total
  const U = S * (T/100);              // Markup em R$
  const W = S + U + V;                // Preço unitário de venda
  const r2 = x => Math.round(x*100)/100;
  return { M:r2(M), N:r2(N), O:r2(O), P:r2(P), Q:r2(Q),
           R:r2(R), S:r2(S), T:r2(T), U:r2(U), V:r2(V), W:r2(W) };
}

// Próximo ID no formato COT00000, baseado no MAIOR número já existente na coluna A
function proximoId(sh){
  const ultima = sh.getLastRow();
  if(ultima < 2) return 'COT00001';
  const col = sh.getRange(2, C_ID, ultima-1, 1).getValues();
  let max = 0;
  col.forEach(r => {
    const m = String(r[0]).match(/COT(\d+)/i);
    if(m){ const n = parseInt(m[1],10); if(n > max) max = n; }
  });
  return 'COT' + String(max+1).padStart(5,'0');
}

// Números das linhas (na planilha) que têm este ID, em ordem
function linhasDoId(sh, id){
  const ultima = sh.getLastRow();
  if(ultima < 2) return [];
  const col = sh.getRange(2, C_ID, ultima-1, 1).getValues();
  const alvo = String(id).trim();
  const out = [];
  for(let i=0; i<col.length; i++) if(String(col[i][0]).trim() === alvo) out.push(i+2);
  return out;
}

function getAba(){
  const ss = SpreadsheetApp.openById(SHEET_ID);
  return ss.getSheetByName(ABA) || ss.getSheets()[0];
}

// Empacota um objeto como resposta JSON (HTTP) do App da Web
function resposta(obj){
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function up(v){ return v == null ? '' : String(v).trim().toUpperCase(); }
function vazio(v){ return v === '' || v === null || v === undefined; }

function num(v){
  if(vazio(v)) return 0;
  if(typeof v === 'number') return v;
  let s = String(v).trim();
  if(s.indexOf(',') >= 0) s = s.replace(/\./g,'').replace(',','.'); // aceita "1.234,56"
  const n = parseFloat(s);
  return isNaN(n) ? 0 : n;
}

// Formata as células de data/moeda/percentual (importante p/ a leitura gviz)
function formatarLinha(sh, l){
  sh.getRange(l, C_DTINC).setNumberFormat(FMT_DATA);
  sh.getRange(l, C_DTCOT).setNumberFormat(FMT_DATA);
  [C_M,C_O,C_R,C_S,C_U,C_V,C_W].forEach(c => sh.getRange(l,c).setNumberFormat(FMT_MOEDA));
  [C_N,C_P,C_Q,C_T].forEach(c => sh.getRange(l,c).setNumberFormat(FMT_PCT));
}

/* Cria o cabeçalho na 1ª linha. Rode UMA vez em planilha vazia (opcional). */
function criarCabecalho(){
  const sh = getAba();
  const cab = ['ID cotacao','data inclusao','representante','cliente','quantidade',
    'unidade de medida','produto','observacao comercial','data cotacao','fornecedor',
    'prazo de entrega','observacao compras','custo produto','ipi (%)','ipi (R$)',
    'frete (%)','diferencial icms (%)','diferencial icms (R$)','custo total',
    'markup (%)','markup (R$)','valor de ajuste','preco venda','urgente','cotacao cancelada'];
  sh.getRange(1, 1, 1, cab.length).setValues([cab]).setFontWeight('bold');
  sh.setFrozenRows(1);
}
